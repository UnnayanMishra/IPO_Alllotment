# IPO Lots Manager

A production-ready React application for managing IPO allotments and tracking lots you apply for. The data is stored in a Google Sheet and accessed via a Google Apps Script web app.

## Features

- **IPO Management**: Create and manage IPO names
- **Lot Tracking**: Add, edit, and delete IPO lot applications
- **Advanced Filtering**: Filter by IPO name, application method, allotment status, and search across fields
- **Sorting & Pagination**: Sort by any column and paginate through results
- **Summary Dashboard**: View total applicants and money in market for selected IPO
- **CSV Import/Export**: Export data to CSV or import lots from CSV with validation
- **Responsive Design**: Mobile-first design that works on all devices
- **Real-time Sync**: Refresh data from Google Sheets at any time
- **Mock Mode**: Built-in mock API for local development without Apps Script

## Tech Stack

- **React 18** with TypeScript
- **Vite** for fast development and optimized builds
- **TailwindCSS** for styling
- **Lucide React** for icons
- **Google Apps Script** for backend (or mock API for development)

## Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

Copy the example environment file:

```bash
cp .env.example .env
```

Edit `.env` and configure:

```env
# Use mock data for local development (no Apps Script needed)
VITE_USE_MOCK=true

# When ready to connect to Apps Script, set VITE_USE_MOCK=false and add your URL:
# VITE_API_BASE_URL=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec

# Enable debug logging (optional)
VITE_DEBUG=false
```

### 3. Run Development Server

```bash
npm run dev
```

The app will run in mock mode by default, with sample data pre-loaded.

## Setting Up Google Apps Script

### Step 1: Create a Google Sheet

1. Create a new Google Sheet
2. Add the following column headers in the first row:
   - `id`, `name`, `pan`, `ipoName`, `appliedBy`, `ipoAllotmentStatus`, `amountApplied`, `amountReverted`, `notes`, `createdAt`

3. Create a second sheet named "IPOs" with a single column header: `ipoName`

### Step 2: Deploy Apps Script

1. In your Google Sheet, go to **Extensions > Apps Script**
2. Delete the default code and paste the following code:

```javascript
// IPO Lots Manager - Google Apps Script Backend
// This script exposes your Google Sheet data as a web API

const SHEET_NAME = 'Sheet1';
const IPO_SHEET_NAME = 'IPOs';

function doGet(e) {
  const action = e.parameter.action || 'list';

  try {
    if (action === 'list') {
      return jsonResponse(listRows());
    } else if (action === 'listIpos') {
      return jsonResponse(listIpos());
    }

    return jsonResponse({ error: 'Invalid action' }, 400);
  } catch (error) {
    return jsonResponse({ error: error.toString() }, 500);
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const action = payload.action;

    if (action === 'addRow') {
      return jsonResponse(addRow(payload.data));
    } else if (action === 'updateRow') {
      return jsonResponse(updateRow(payload.id, payload.data));
    } else if (action === 'deleteRow') {
      return jsonResponse(deleteRow(payload.id));
    } else if (action === 'addIpo') {
      return jsonResponse(addIpo(payload.ipoName));
    }

    return jsonResponse({ error: 'Invalid action' }, 400);
  } catch (error) {
    return jsonResponse({ error: error.toString() }, 500);
  }
}

function listRows() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const rows = data.slice(1);

  return rows.map(row => {
    const obj = {};
    headers.forEach((header, index) => {
      obj[header] = row[index];
    });
    return obj;
  });
}

function listIpos() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(IPO_SHEET_NAME);
  if (!sheet) return [];

  const data = sheet.getDataRange().getValues();
  const ipos = data.slice(1).map(row => row[0]).filter(name => name);
  return ipos;
}

function addRow(rowData) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const id = 'row-' + new Date().getTime();
  const createdAt = new Date().toISOString();

  const newRow = {
    id: id,
    name: rowData.name,
    pan: rowData.pan,
    ipoName: rowData.ipoName,
    appliedBy: rowData.appliedBy,
    ipoAllotmentStatus: rowData.ipoAllotmentStatus,
    amountApplied: rowData.amountApplied,
    amountReverted: rowData.amountReverted,
    notes: rowData.notes || '',
    createdAt: createdAt
  };

  sheet.appendRow([
    newRow.id,
    newRow.name,
    newRow.pan,
    newRow.ipoName,
    newRow.appliedBy,
    newRow.ipoAllotmentStatus,
    newRow.amountApplied,
    newRow.amountReverted,
    newRow.notes,
    newRow.createdAt
  ]);

  return newRow;
}

function updateRow(id, rowData) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const idIndex = headers.indexOf('id');

  for (let i = 1; i < data.length; i++) {
    if (data[i][idIndex] === id) {
      // Update only provided fields
      Object.keys(rowData).forEach(key => {
        const colIndex = headers.indexOf(key);
        if (colIndex !== -1) {
          sheet.getRange(i + 1, colIndex + 1).setValue(rowData[key]);
        }
      });

      // Return updated row
      const updatedData = sheet.getRange(i + 1, 1, 1, headers.length).getValues()[0];
      const updatedRow = {};
      headers.forEach((header, index) => {
        updatedRow[header] = updatedData[index];
      });
      return updatedRow;
    }
  }

  throw new Error('Row not found');
}

function deleteRow(id) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  const idIndex = data[0].indexOf('id');

  for (let i = 1; i < data.length; i++) {
    if (data[i][idIndex] === id) {
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }

  throw new Error('Row not found');
}

function addIpo(ipoName) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(IPO_SHEET_NAME);

  // Check for duplicates
  const data = sheet.getDataRange().getValues();
  const existing = data.slice(1).map(row => row[0]);

  if (existing.includes(ipoName)) {
    throw new Error('IPO name already exists');
  }

  sheet.appendRow([ipoName]);
  return { ipoName: ipoName };
}

function jsonResponse(data, statusCode = 200) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
```

3. Click **Deploy > New deployment**
4. Select type: **Web app**
5. Configure:
   - **Execute as**: Me
   - **Who has access**: Anyone (or Anyone with Google account if you need auth)
6. Click **Deploy**
7. Copy the web app URL

### Step 3: Configure Your App

1. Update `.env`:
   ```env
   VITE_USE_MOCK=false
   VITE_API_BASE_URL=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec
   ```

2. Restart your development server

## API Contract

The Google Apps Script backend implements the following API:

### GET Requests

- `?action=list` - Returns all rows as JSON array
- `?action=listIpos` - Returns all IPO names as JSON array

### POST Requests (JSON body)

- `{ action: "addRow", data: {...} }` - Adds a new row
- `{ action: "updateRow", id: "row-123", data: {...} }` - Updates a row
- `{ action: "deleteRow", id: "row-123" }` - Deletes a row
- `{ action: "addIpo", ipoName: "..." }` - Creates a new IPO name

### Row Data Format

```typescript
{
  id: string;              // Auto-generated
  name: string;            // Applicant name
  pan: string;             // PAN card number
  ipoName: string;         // IPO name (must exist in IPOs sheet)
  appliedBy: string;       // "online" | "offline" | "broker"
  ipoAllotmentStatus: string; // "Pending" | "Allotted" | "Not Allotted" | "Refund Received"
  amountApplied: number;   // Amount applied in INR
  amountReverted: number;  // Amount refunded in INR
  notes?: string;          // Optional notes
  createdAt: string;       // ISO timestamp
}
```

## Troubleshooting

### CORS Issues

If you encounter CORS errors:

1. Ensure your Apps Script is deployed as described above
2. Make sure "Who has access" is set to "Anyone" or "Anyone with Google account"
3. Redeploy the Apps Script web app (create a new deployment)

### Apps Script Returns HTML Instead of JSON

This usually happens when:

1. The script has an error - check Apps Script logs
2. Authorization is required - visit the web app URL in a browser and authorize it
3. The deployment settings are incorrect

### Mock Mode Not Working

Ensure `.env` has:
```env
VITE_USE_MOCK=true
```

Then restart the dev server.

## Building for Production

```bash
npm run build
```

The optimized production build will be in the `dist/` directory.

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── TopNav.tsx
│   ├── FiltersPanel.tsx
│   ├── SummaryCard.tsx
│   ├── ApplicantsTable.tsx
│   ├── Pagination.tsx
│   ├── CreateIpoModal.tsx
│   ├── EditLotModal.tsx
│   ├── DeleteConfirmModal.tsx
│   ├── CsvImportExport.tsx
│   └── Toast.tsx
├── hooks/              # Custom React hooks
│   ├── useApi.ts
│   ├── useFetchRows.ts
│   ├── useIpoList.ts
│   └── usePagination.ts
├── services/           # API clients
│   ├── ApiClient.ts    # Google Apps Script client
│   └── MockApiClient.ts # Mock data for development
├── types/              # TypeScript type definitions
│   └── index.ts
├── App.tsx             # Main application
├── main.tsx           # Entry point
└── index.css          # Global styles
```

## License

MIT

## Support

For issues or questions, please refer to the Google Apps Script documentation or React documentation.
