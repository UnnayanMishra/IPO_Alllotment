import type { IpoRow, IpoRowInput, ApiResponse } from '../types';

const DEBUG = import.meta.env.VITE_DEBUG === 'true';

interface RetryConfig {
  maxRetries: number;
  baseDelay: number;
  maxDelay: number;
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  baseDelay: 1000,
  maxDelay: 10000,
};

class ApiClient {
  private baseUrl: string;
  private retryConfig: RetryConfig;

  constructor(baseUrl: string, retryConfig: Partial<RetryConfig> = {}) {
    this.baseUrl = baseUrl;
    this.retryConfig = { ...DEFAULT_RETRY_CONFIG, ...retryConfig };
  }

  private log(...args: unknown[]) {
    if (DEBUG) {
      console.log('[ApiClient]', ...args);
    }
  }

  private async sleep(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private calculateBackoff(attempt: number): number {
    const delay = Math.min(
      this.retryConfig.baseDelay * Math.pow(2, attempt),
      this.retryConfig.maxDelay
    );
    return delay + Math.random() * 1000;
  }

  private async fetchWithRetry(
    url: string,
    options: RequestInit,
    attempt = 0
  ): Promise<Response> {
    try {
      this.log(`Attempt ${attempt + 1}: ${options.method || 'GET'} ${url}`);
      const response = await fetch(url, options);

      if (response.ok) {
        return response;
      }

      if (response.status >= 500 && attempt < this.retryConfig.maxRetries) {
        const delay = this.calculateBackoff(attempt);
        this.log(`Server error (${response.status}), retrying in ${delay}ms...`);
        await this.sleep(delay);
        return this.fetchWithRetry(url, options, attempt + 1);
      }

      return response;
    } catch (error) {
      if (attempt < this.retryConfig.maxRetries) {
        const delay = this.calculateBackoff(attempt);
        this.log(`Network error, retrying in ${delay}ms...`, error);
        await this.sleep(delay);
        return this.fetchWithRetry(url, options, attempt + 1);
      }
      throw error;
    }
  }

  private async tryJsonThenFormEncoded(
    url: string,
    payload: Record<string, unknown>
  ): Promise<Response> {
    try {
      const jsonResponse = await this.fetchWithRetry(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (jsonResponse.ok || (jsonResponse.status !== 400 && jsonResponse.status !== 415)) {
        return jsonResponse;
      }

      this.log('JSON failed with 400/415, trying form-encoded...');
    } catch (error) {
      this.log('JSON request failed, trying form-encoded...', error);
    }

    const formBody = `payload=${encodeURIComponent(JSON.stringify(payload))}`;
    return this.fetchWithRetry(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formBody,
    });
  }

  async listRows(): Promise<ApiResponse<IpoRow[]>> {
    try {
      const url = `${this.baseUrl}?action=list`;
      const response = await this.fetchWithRetry(url, { method: 'GET' });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data: Array.isArray(data) ? data : [] };
    } catch (error) {
      this.log('Error in listRows:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch rows',
      };
    }
  }

  async listIpos(): Promise<ApiResponse<string[]>> {
    try {
      const url = `${this.baseUrl}?action=listIpos`;
      const response = await this.fetchWithRetry(url, { method: 'GET' });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data: Array.isArray(data) ? data : [] };
    } catch (error) {
      this.log('Error in listIpos:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch IPO list',
      };
    }
  }

  async addRow(rowData: IpoRowInput): Promise<ApiResponse<IpoRow>> {
    try {
      const payload = { action: 'addRow', data: rowData };
      const response = await this.tryJsonThenFormEncoded(this.baseUrl, payload);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      this.log('Error in addRow:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to add row',
      };
    }
  }

  async updateRow(id: string, rowData: Partial<IpoRowInput>): Promise<ApiResponse<IpoRow>> {
    try {
      const payload = { action: 'updateRow', id, data: rowData };
      const response = await this.tryJsonThenFormEncoded(this.baseUrl, payload);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      this.log('Error in updateRow:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update row',
      };
    }
  }

  async deleteRow(id: string): Promise<ApiResponse<void>> {
    try {
      const payload = { action: 'deleteRow', id };
      const response = await this.tryJsonThenFormEncoded(this.baseUrl, payload);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
      }

      return { success: true };
    } catch (error) {
      this.log('Error in deleteRow:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to delete row',
      };
    }
  }

  async addIpo(ipoName: string): Promise<ApiResponse<string>> {
    try {
      const payload = { action: 'addIpo', ipoName };
      const response = await this.tryJsonThenFormEncoded(this.baseUrl, payload);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data: data.ipoName || ipoName };
    } catch (error) {
      this.log('Error in addIpo:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to add IPO',
      };
    }
  }
}

export default ApiClient;
