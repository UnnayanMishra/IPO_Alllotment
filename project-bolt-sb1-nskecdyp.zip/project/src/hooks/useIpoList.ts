import { useState, useEffect, useCallback } from 'react';
import { useApi } from './useApi';

export function useIpoList() {
  const [ipos, setIpos] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const api = useApi();

  const fetchIpos = useCallback(async () => {
    setLoading(true);
    setError(null);

    const response = await api.listIpos();

    if (response.success && response.data) {
      setIpos(response.data);
    } else {
      setError(response.error || 'Failed to fetch IPO list');
    }

    setLoading(false);
  }, [api]);

  useEffect(() => {
    fetchIpos();
  }, [fetchIpos]);

  const addIpo = useCallback(
    async (ipoName: string) => {
      const response = await api.addIpo(ipoName);
      if (response.success) {
        await fetchIpos();
      }
      return response;
    },
    [api, fetchIpos]
  );

  return { ipos, loading, error, refresh: fetchIpos, addIpo };
}
