import { useState, useMemo, useCallback } from 'react';
import { TopNav } from './components/TopNav';
import { FiltersPanel } from './components/FiltersPanel';
import { SummaryCard } from './components/SummaryCard';
import { ApplicantsTable } from './components/ApplicantsTable';
import { Pagination } from './components/Pagination';
import { CreateIpoModal } from './components/CreateIpoModal';
import { EditLotModal } from './components/EditLotModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { CsvImportExport } from './components/CsvImportExport';
import { Toast } from './components/Toast';
import { useFetchRows } from './hooks/useFetchRows';
import { useIpoList } from './hooks/useIpoList';
import { usePagination } from './hooks/usePagination';
import { useApi } from './hooks/useApi';
import type { IpoRow, IpoRowInput, FilterState, SortState } from './types';

interface ToastState {
  message: string;
  type: 'success' | 'error' | 'info';
}

function App() {
  const { rows, loading, error, lastSync, refresh, setRows } = useFetchRows();
  const { ipos, addIpo } = useIpoList();
  const api = useApi();

  const [filters, setFilters] = useState<FilterState>({
    ipoName: '',
    appliedBy: '',
    allotmentStatus: '',
    searchQuery: '',
  });

  const [sortState, setSortState] = useState<SortState>({
    field: 'createdAt',
    direction: 'desc',
  });

  const [isCreateIpoModalOpen, setIsCreateIpoModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingRow, setEditingRow] = useState<IpoRow | null>(null);
  const [deletingRow, setDeletingRow] = useState<IpoRow | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  }, []);

  const filteredAndSortedRows = useMemo(() => {
    let filtered = [...rows];

    if (filters.ipoName) {
      filtered = filtered.filter(row => row.ipoName === filters.ipoName);
    }

    if (filters.appliedBy) {
      filtered = filtered.filter(row => row.appliedBy === filters.appliedBy);
    }

    if (filters.allotmentStatus) {
      filtered = filtered.filter(row => row.ipoAllotmentStatus === filters.allotmentStatus);
    }

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      filtered = filtered.filter(
        row =>
          row.name.toLowerCase().includes(query) ||
          row.pan.toLowerCase().includes(query) ||
          row.ipoName.toLowerCase().includes(query) ||
          (row.notes && row.notes.toLowerCase().includes(query))
      );
    }

    if (sortState.field) {
      filtered.sort((a, b) => {
        const aVal = a[sortState.field!];
        const bVal = b[sortState.field!];

        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return sortState.direction === 'asc'
            ? aVal.localeCompare(bVal)
            : bVal.localeCompare(aVal);
        }

        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortState.direction === 'asc' ? aVal - bVal : bVal - aVal;
        }

        return 0;
      });
    }

    return filtered;
  }, [rows, filters, sortState]);

  const { paginatedItems, pagination, totalPages, goToPage, nextPage, prevPage, setPageSize } =
    usePagination(filteredAndSortedRows, 10);

  const handleSort = (field: keyof IpoRow) => {
    setSortState(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refresh();
    setIsRefreshing(false);
    showToast('Data refreshed successfully', 'success');
  };

  const handleCreateIpo = async (ipoName: string) => {
    const response = await addIpo(ipoName);
    if (response.success) {
      showToast(`IPO "${ipoName}" created successfully`, 'success');
    } else {
      showToast(response.error || 'Failed to create IPO', 'error');
      throw new Error(response.error);
    }
  };

  const handleAddOrUpdateLot = async (data: IpoRowInput, id?: string) => {
    if (id) {
      const response = await api.updateRow(id, data);
      if (response.success && response.data) {
        setRows(prev => prev.map(row => (row.id === id ? response.data! : row)));
        showToast('Lot updated successfully', 'success');
      } else {
        showToast(response.error || 'Failed to update lot', 'error');
        throw new Error(response.error);
      }
    } else {
      const response = await api.addRow(data);
      if (response.success && response.data) {
        setRows(prev => [...prev, response.data!]);
        showToast('Lot added successfully', 'success');
      } else {
        showToast(response.error || 'Failed to add lot', 'error');
        throw new Error(response.error);
      }
    }
  };

  const handleEdit = (row: IpoRow) => {
    setEditingRow(row);
    setIsEditModalOpen(true);
  };

  const handleDelete = (row: IpoRow) => {
    setDeletingRow(row);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deletingRow) return;

    const response = await api.deleteRow(deletingRow.id);
    if (response.success) {
      setRows(prev => prev.filter(row => row.id !== deletingRow.id));
      showToast('Lot deleted successfully', 'success');
    } else {
      showToast(response.error || 'Failed to delete lot', 'error');
    }

    setIsDeleteModalOpen(false);
    setDeletingRow(null);
  };

  const handleImportRows = async (importedRows: IpoRowInput[]) => {
    for (const row of importedRows) {
      const response = await api.addRow(row);
      if (response.success && response.data) {
        setRows(prev => [...prev, response.data!]);
      }
    }
    showToast(`${importedRows.length} row(s) imported successfully`, 'success');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading IPO data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white border border-red-200 rounded-lg p-6 shadow-lg">
          <h2 className="text-lg font-semibold text-red-900 mb-2">Connection Error</h2>
          <p className="text-gray-700 mb-4">{error}</p>
          <p className="text-sm text-gray-600 mb-4">
            Please check your Apps Script configuration or enable mock mode for local development.
          </p>
          <button
            onClick={refresh}
            className="w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopNav
        onCreateIpo={() => setIsCreateIpoModalOpen(true)}
        onAddLot={() => {
          setEditingRow(null);
          setIsEditModalOpen(true);
        }}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
        lastSync={lastSync}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <aside className="lg:col-span-1">
            <FiltersPanel filters={filters} onFiltersChange={setFilters} ipoList={ipos} />
          </aside>

          <div className="lg:col-span-3 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">
                {filteredAndSortedRows.length} Record{filteredAndSortedRows.length !== 1 ? 's' : ''}
              </h2>
              <CsvImportExport rows={rows} onImport={handleImportRows} ipoList={ipos} />
            </div>

            <SummaryCard rows={filteredAndSortedRows} selectedIpo={filters.ipoName} />

            <ApplicantsTable
              rows={paginatedItems}
              onEdit={handleEdit}
              onDelete={handleDelete}
              sortState={sortState}
              onSort={handleSort}
            />

            <Pagination
              pagination={pagination}
              totalPages={totalPages}
              onPageChange={goToPage}
              onPageSizeChange={setPageSize}
            />
          </div>
        </div>
      </main>

      <CreateIpoModal
        isOpen={isCreateIpoModalOpen}
        onClose={() => setIsCreateIpoModalOpen(false)}
        onSubmit={handleCreateIpo}
        existingIpos={ipos}
      />

      <EditLotModal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setEditingRow(null);
        }}
        onSubmit={handleAddOrUpdateLot}
        ipoList={ipos}
        editingRow={editingRow}
      />

      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setDeletingRow(null);
        }}
        onConfirm={handleConfirmDelete}
        row={deletingRow}
      />

      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}
    </div>
  );
}

export default App;
