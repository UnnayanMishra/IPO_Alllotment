export interface IpoRow {
  id: string;
  name: string;
  pan: string;
  ipoName: string;
  appliedBy: 'online' | 'offline' | 'broker';
  ipoAllotmentStatus: 'Pending' | 'Allotted' | 'Not Allotted' | 'Refund Received';
  amountApplied: number;
  amountReverted: number;
  notes?: string;
  createdAt: string;
}

export interface IpoRowInput {
  name: string;
  pan: string;
  ipoName: string;
  appliedBy: string;
  ipoAllotmentStatus: string;
  amountApplied: number;
  amountReverted: number;
  notes?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface PaginationState {
  currentPage: number;
  pageSize: number;
  totalItems: number;
}

export interface FilterState {
  ipoName: string;
  appliedBy: string;
  allotmentStatus: string;
  searchQuery: string;
}

export interface SortState {
  field: keyof IpoRow | null;
  direction: 'asc' | 'desc';
}
