import { TrendingUp, Users, DollarSign } from 'lucide-react';
import type { IpoRow } from '../types';

interface SummaryCardProps {
  rows: IpoRow[];
  selectedIpo: string;
}

export function SummaryCard({ rows, selectedIpo }: SummaryCardProps) {
  const filteredRows = selectedIpo ? rows.filter(r => r.ipoName === selectedIpo) : rows;

  const totalApplicants = filteredRows.length;
  const totalApplied = filteredRows.reduce((sum, row) => sum + row.amountApplied, 0);
  const totalReverted = filteredRows.reduce((sum, row) => sum + row.amountReverted, 0);
  const totalInMarket = totalApplied - totalReverted;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-4">
      <h2 className="text-sm font-semibold text-gray-900 mb-4">
        {selectedIpo ? `Summary: ${selectedIpo}` : 'Overall Summary'}
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            <Users className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <p className="text-xs text-gray-600">Total Applicants</p>
            <p className="text-xl font-bold text-gray-900">{totalApplicants}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-2 bg-green-50 rounded-lg">
            <DollarSign className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <p className="text-xs text-gray-600">Amount Applied</p>
            <p className="text-xl font-bold text-gray-900">{formatCurrency(totalApplied)}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-2 bg-orange-50 rounded-lg">
            <DollarSign className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <p className="text-xs text-gray-600">Amount Reverted</p>
            <p className="text-xl font-bold text-gray-900">{formatCurrency(totalReverted)}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-2 bg-purple-50 rounded-lg">
            <TrendingUp className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <p className="text-xs text-gray-600">Money in Market</p>
            <p className="text-xl font-bold text-gray-900">{formatCurrency(totalInMarket)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
